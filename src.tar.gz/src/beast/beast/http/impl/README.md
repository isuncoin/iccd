git-subtree: "http-parser"
remote: https://github.com/joyent/http-parser.git
branch: master
